package com.example.susheguanli.controller;

import com.example.susheguanli.dao.ManMationDao;
import com.example.susheguanli.doman.ManMation;
import com.example.susheguanli.service.ManMationservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/manMation")
@CrossOrigin
public class ManMationController {
    @Autowired
    private ManMationservice manMationservice;
    @GetMapping
    public List<ManMation> getAll(){
        List<ManMation>  list= manMationservice.list();

        for (ManMation manMation :list){
            System.out.println(manMation.toString());
        }
        return manMationservice.list();
    }
    @GetMapping("/search/{name}")
    public ManMation getByName(@PathVariable String name){
        System.out.println(name);
        List<ManMation> manMationList= manMationservice.list();
        for (ManMation manMation: manMationList){
            if(manMation.getManagerName().equals(name)){
                System.out.println("+++"+manMation.getManagerName());
                return manMation;
            }

        }
        return null;
    }

    @PostMapping("/add")
    public boolean save(@RequestBody ManMation manMation){
        System.out.println(manMation.getManagerNum()+"--"+manMation.getManagerName()+"--"+manMation.getManagerCard()
                +"--"+manMation.getManagerGender()+"--"+manMation.getManagerBirthday()+"--"+manMation.getManagerNational()
                +"--"+manMation.getManagerBuilding()+"--"+manMation.getManagerTel()
                +"--"+manMation.getManagerQq()+"--"+manMation.getManagerEmail());
        System.out.println(manMation.getManagerName());
        return manMationservice.save(manMation);
    }
    @Autowired
    ManMationDao manMationDao;
    @DeleteMapping("/{id}")
    public boolean userdelete(@PathVariable Integer id){
        System.out.println(id);
        return manMationDao.deleteById(id)>0;
    }


    @PutMapping
    public boolean update1(@RequestBody ManMation manMation){
        return manMationservice.updateById(manMation);
    }


    @GetMapping("/{id}")
    public ManMation getByid(@PathVariable int id){

        List<ManMation> manMationList= manMationservice.list();
        for (ManMation manMation: manMationList){
            if(manMation.getManagerId()==id){
                return manMation;
            }

        }
        return null;
    }


}

