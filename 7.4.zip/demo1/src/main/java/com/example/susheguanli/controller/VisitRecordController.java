package com.example.susheguanli.controller;

import com.example.susheguanli.dao.VisitRecordDao;
import com.example.susheguanli.doman.VisitRecord;
import com.example.susheguanli.service.VisitRecordservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/visitRecord")
@CrossOrigin
public class VisitRecordController {
    @Autowired
    private VisitRecordservice visitRecordservice;
    @GetMapping
    public List<VisitRecord> getAll(){
        List<VisitRecord> list= visitRecordservice.list();

        for (VisitRecord visitRecord :list){
            System.out.println(visitRecord.toString());
        }
        return visitRecordservice.list();
    }
    @GetMapping("/search/{name}")
    public VisitRecord getByName(@PathVariable String name){
        System.out.println(name);
        List<VisitRecord> visitRecordList= visitRecordservice.list();
        for (VisitRecord visitRecord: visitRecordList){
            if(visitRecord.getTouristName().equals(name)){
                System.out.println("+++"+visitRecord.getTouristName());
                return visitRecord;
            }

        }
        return null;
    }

    @PostMapping("/add")
    public boolean save(@RequestBody VisitRecord visitRecord){
        System.out.println(visitRecord.getTouristName()+"--"+visitRecord.getTouristNum()+"--"+visitRecord.getVisitingDormitory()
                +"--"+visitRecord.getVisitingCourse()+"--"+visitRecord.getVisitingTel());
        System.out.println(visitRecord.getTouristName());
        return visitRecordservice.save(visitRecord);
    }
    @Autowired
    VisitRecordDao visitRecordDao;
    @DeleteMapping("/{id}")
    public boolean userdelete(@PathVariable int id){
        System.out.println(id);
        return visitRecordDao.deleteById(id)>0;
    }


    @PutMapping
    public boolean update1(@RequestBody VisitRecord visitRecord){
        return visitRecordservice.updateById(visitRecord);
    }


    @GetMapping("/{id}")
    public VisitRecord getByid(@PathVariable int id){

        List<VisitRecord> visitRecordList= visitRecordservice.list();
        for (VisitRecord visitRecord: visitRecordList){
            if(visitRecord.getTouristId()==id){
                return visitRecord;
            }

        }
        return null;
    }


}