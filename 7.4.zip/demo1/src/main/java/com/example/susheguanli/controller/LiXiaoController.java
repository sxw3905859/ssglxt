package com.example.susheguanli.controller;


import com.example.susheguanli.dao.LiXiaoDao;
import com.example.susheguanli.doman.LiXiao;
import com.example.susheguanli.service.LiXiaoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/liXiao")
@CrossOrigin
public class LiXiaoController {
    @Autowired
    private LiXiaoService liXiaoservice;
    @GetMapping
    public List<LiXiao> getAll(){
        System.out.println(100000);
        List<LiXiao>  list= liXiaoservice.list();
        for (LiXiao liXiao :list){
            System.out.println(liXiao.toString());
        }
        return liXiaoservice.list();
    }
//    根据姓名匹配
    @GetMapping("/search/{name}")
    public LiXiao getByName(@PathVariable String name){
        System.out.println(name);
        List<LiXiao> liXiaoList= liXiaoservice.list();
        for (LiXiao liXiao: liXiaoList){
            if(liXiao.getStudentName().equals(name)){
                System.out.println("+++"+liXiao.getStudentName());
                return liXiao;
            }

        }
        return null;
    }

    @PostMapping("/add")
    public boolean save(@RequestBody LiXiao liXiao){
        System.out.println(liXiao.getStudentNum()+"--"+liXiao.getStudentName()+"--"+liXiao.getDormitoryNum()
                +"--"+liXiao.getStartTime()+"--"+liXiao.getFinishTime()+"--"+liXiao.getLeavingReason()+"--"+liXiao.getStudentTel());
        System.out.println(liXiao.getStudentName());
        return liXiaoservice.save(liXiao);
    }
    @Autowired
    LiXiaoDao liXiaoDao;
    @DeleteMapping("/{id}")
    public boolean userdelete(@PathVariable int id){
        System.out.println(id);
        return liXiaoDao.deleteById(id)>0;
    }


    @PutMapping
    public boolean update1(@RequestBody LiXiao liXiao){
        return liXiaoservice.updateById(liXiao);
    }


    @GetMapping("/{id}")
    public LiXiao getByid(@PathVariable int id){

        List<LiXiao> liXiaoList= liXiaoservice.list();
        for (LiXiao liXiao: liXiaoList){
            if(liXiao.getLeavingId()==id){
                return liXiao;
            }

        }
        return null;
    }


}
