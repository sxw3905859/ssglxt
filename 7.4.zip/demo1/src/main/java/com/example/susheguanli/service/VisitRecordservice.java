package com.example.susheguanli.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.susheguanli.doman.VisitRecord;

public interface VisitRecordservice extends IService<VisitRecord> {
    VisitRecord getVisitRecord(String touristName, String touristNum, String visitingDormitory
            , String visitingCourse, String visitingTel);
}