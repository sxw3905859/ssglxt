package com.example.susheguanli.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.susheguanli.dao.VisitRecordDao;
import com.example.susheguanli.doman.VisitRecord;
import com.example.susheguanli.service.VisitRecordservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VisitRecordServiceImpl extends ServiceImpl<VisitRecordDao, VisitRecord> implements VisitRecordservice {

    @Autowired
    VisitRecordDao visitRecordDao;

    @Override
    public VisitRecord getVisitRecord(String touristName, String touristNum, String visitingDormitory
            , String visitingCourse, String visitingTel) {
        return visitRecordDao.getVisitRecord(touristName , touristNum,visitingDormitory,visitingCourse,visitingTel);
    }
}
