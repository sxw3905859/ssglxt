package com.example.susheguanli.doman;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

@TableName("xs_leaving_application")
public class LiXiao {
    @TableId("leaving_id")
    private Integer leavingId;
    private String studentNum;
    private String studentName;
    private String dormitoryNum;
    private String startTime;
    private String finishTime;
    private String leavingReason;
    private String studentTel;

    @Override
    public String toString() {
        return "LiXiao{" +
                "leavingId=" + leavingId +
                ", studentNum= '" + studentNum + '\'' +
                ", studentName='" + studentName + '\'' +
                ", dormitoryNum='" + dormitoryNum + '\'' +
                ", startTime='" + startTime + '\'' +
                ", finishTime='" + finishTime + '\'' +
                ", leavingReason='" + leavingReason + '\'' +
                ", studentTel='" + studentTel + '\'' +
                '}';
    }

    public Integer getLeavingId() {
        return leavingId;
    }

    public void setLeavingId(Integer leavingId) {
        this.leavingId = leavingId;
    }

    public String getStudentNum() {
        return studentNum;
    }

    public void setStudentNum(String studentNum) {
        this.studentNum = studentNum;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getDormitoryNum() {
        return dormitoryNum;
    }

    public void setDormitoryNum(String dormitoryNum) {
        this.dormitoryNum = dormitoryNum;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getFinishTime() {
        return finishTime;
    }

    public void setFinishTime(String finishTime) {
        this.finishTime = finishTime;
    }

    public String getLeavingReason() {
        return leavingReason;
    }

    public void setLeavingReason(String leavingReason) {
        this.leavingReason = leavingReason;
    }

    public String getStudentTel() {
        return studentTel;
    }

    public void setStudentTel(String studentTel) {
        this.studentTel = studentTel;
    }
}