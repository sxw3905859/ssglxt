package com.example.susheguanli.doman;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

@TableName("ad_manager_information")
public class ManMation   {
    @TableId("manager_id")
        private  Integer managerId;
        private  Integer managerNum;
        private  String managerName;
        private  String managerCard;
        private String managerGender;
        private String managerBirthday;
        private String managerNational;
         private  String managerBuilding;
         private String managerTel;
         private String managerQq;
         private String managerEmail;

        @Override
        public String toString() {
            return "ManMation{" +
                    "managerId=" + managerId +
                    ", managerNum='" + managerNum + '\'' +
                    ", managerName='" + managerName + '\'' +
                    ", managerCard='" + managerCard + '\'' +
                    ", managerGender='" + managerGender + '\'' +
                    ", managerBirthday='" + managerBirthday + '\'' +
                    ", managerNational='" + managerNational + '\'' +
                    ", managerNational='" + managerBuilding + '\'' +
                    ", managerNational='" + managerTel + '\'' +
                    ", managerNational='" + managerQq + '\'' +
                    ", managerNational='" + managerEmail + '\'' +
                    '}';
        }

        public Integer getManagerId() {
            return managerId;
        }
        public void setManagerId(Integer managerId) {
            this.managerId = managerId;
        }

        public Integer getManagerNum() {
            return managerNum;
        }
        public void setManagerNum(Integer managerNum) {
            this.managerNum = managerNum;
        }

        public String getManagerName() {
            return managerName;
        }
        public void setManagerName(String managerName) {
            this.managerName = managerName;
        }

        public String getManagerCard() {
            return managerCard;
        }
        public void setManagerCard(String managerCard) {
            this.managerCard = managerCard;
        }

        public String getManagerGender() {
            return managerGender;
        }
        public void setManagerGender(String managerGender) {
            this.managerGender = managerGender;
        }

        public String getManagerBirthday() {
            return managerBirthday;
        }
        public void setManagerBirthday(String managerBirthday) {
            this.managerBirthday = managerBirthday;
        }

        public String getManagerNational() {
            return managerNational;
        }
        public void setManagerNational(String managerNational) {
            this.managerNational = managerNational;
        }

    public String getManagerBuilding() {
        return managerBuilding;
    }
    public void setManagerBuilding(String managerBuilding) {
        this.managerBuilding = managerBuilding;
    }

    public String getManagerTel() {
        return managerTel;
    }
    public void setManagerTel(String managerTel) {
        this.managerTel = managerTel;
    }

    public String getManagerQq() {
        return managerQq;
    }
    public void setManagerQq(String managerQq) {
        this.managerQq = managerQq;
    }

    public String getManagerEmail() {
        return managerEmail;
    }
    public void setManagerEmail(String managerEmail) {
        this.managerEmail = managerEmail;
    }
}
