package com.example.susheguanli.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.susheguanli.doman.LiXiao;

public interface LiXiaoService extends IService<LiXiao> {
}
