package com.example.susheguanli.doman;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

@TableName("sg_dormitory_information")
public class DormInfo {
    @TableId("dormitory_id")
    private Integer dormitoryId;
    private Integer dormitoryNum;
    private Integer dormitoryMax;
    private Integer dormitoryNow;
    ;


    @Override
    public String toString() {
        return "DormInfo{" +
                "dormitoryId=" + dormitoryId +
                ", dormitoryNum='" + dormitoryNum + '\'' +
                ", dormitoryMax='" + dormitoryMax + '\'' +
                ", dormitoryNow='" + dormitoryNow + '\'' +
                '}';
    }

    public Integer getDormitoryId() {
        return dormitoryId;
    }

    public void setDormitoryId(Integer dormitoryId) {
        this.dormitoryId = dormitoryId;
    }

    public Integer getDormitoryNum() {
        return dormitoryNum;
    }

    public void setDormitoryNum(Integer dormitoryNum) {
        this.dormitoryNum = dormitoryNum;
    }

    public Integer getDormitoryMax() {
        return dormitoryMax;
    }

    public void setDormitoryMax(Integer dormitoryMax) {
        this.dormitoryMax = dormitoryMax;
    }

    public Integer getDormitoryNow() {
        return dormitoryNow;
    }

    public void setDormitoryNow(Integer dormitoryNow) {
        this.dormitoryNow = dormitoryNow;
    }
}
