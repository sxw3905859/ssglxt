package com.example.susheguanli.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.susheguanli.doman.ManMation;

public interface ManMationservice extends IService<ManMation> {
    ManMation getManMation(Integer managerNum, String managerName, String managerCard
            , String managerGender, String managerBirthday, String managerNational
            , String managerBuilding, String managerTel, String managerQq, String managerEmail);
}