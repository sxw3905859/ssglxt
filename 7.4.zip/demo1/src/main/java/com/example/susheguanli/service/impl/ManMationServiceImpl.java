package com.example.susheguanli.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.susheguanli.dao.ManMationDao;
import com.example.susheguanli.doman.ManMation;
import com.example.susheguanli.service.ManMationservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ManMationServiceImpl extends ServiceImpl<ManMationDao, ManMation> implements ManMationservice {

    @Autowired
    ManMationDao manMationDao;

    @Override
    public ManMation getManMation(Integer managerNum, String managerName, String managerCard
            , String managerGender, String managerBirthday, String managerNational
            , String managerBuilding, String managerTel, String managerQq, String managerEmail) {
        return manMationDao.getManMation(managerNum , managerName,managerCard,managerGender,managerBirthday,managerNational
                , managerBuilding,managerTel,managerQq,managerEmail);
    }
}