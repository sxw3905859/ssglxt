package com.example.susheguanli.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.susheguanli.dao.LiXiaoDao;
import com.example.susheguanli.doman.LiXiao;
import com.example.susheguanli.service.LiXiaoService;
import org.springframework.stereotype.Service;

@Service
public class LiXiaoServiceImpl extends ServiceImpl<LiXiaoDao, LiXiao> implements LiXiaoService {
}
