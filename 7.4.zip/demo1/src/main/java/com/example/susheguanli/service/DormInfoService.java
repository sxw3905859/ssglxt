package com.example.susheguanli.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.susheguanli.doman.DormInfo;

public interface DormInfoService  extends IService<DormInfo> {
}
