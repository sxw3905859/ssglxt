package com.example.susheguanli.controller;

import com.example.susheguanli.dao.StuMationDao;
import com.example.susheguanli.doman.StuMation;
import com.example.susheguanli.service.StuMationservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/stuMation")
@CrossOrigin
public class StuMationController {
    @Autowired
    private StuMationservice stuMationservice;
    @GetMapping
    public List<StuMation> getAll(){
        List<StuMation>  list= stuMationservice.list();

      for (StuMation stuMation :list){
          System.out.println(stuMation.toString());
      }
        return stuMationservice.list();
    }
    @GetMapping("/search/{name}")
    public StuMation getByName(@PathVariable String name){
        System.out.println(name);
        List<StuMation> stuMationList= stuMationservice.list();
        for (StuMation stuMation: stuMationList){
            if(stuMation.getStudentName().equals(name)){
                System.out.println("+++"+stuMation.getStudentName());
                return stuMation;
            }

        }
        return null;
    }

    @PostMapping("/add")
    public boolean save(@RequestBody StuMation stuMation){
        System.out.println(stuMation.getStudentNum()+"--"+stuMation.getStudentName()+"--"+stuMation.getStudentNational()
                +"--"+stuMation.getStudentClass()+"--"+stuMation.getStudentGender()+"--"+stuMation.getStudentTel());
        System.out.println(stuMation.getStudentName());
        return stuMationservice.save(stuMation);
    }
    @Autowired
    StuMationDao stuMationDao;
    @DeleteMapping("/{id}")
    public boolean userdelete(@PathVariable int id){
        System.out.println(id);
        return stuMationDao.deleteById(id)>0;
    }


    @PutMapping
    public boolean update1(@RequestBody StuMation stuMation){
        return stuMationservice.updateById(stuMation);
    }


    @GetMapping("/{id}")
    public StuMation getByid(@PathVariable int id){

        List<StuMation> stuMationList= stuMationservice.list();
        for (StuMation stuMation: stuMationList){
            if(stuMation.getStudentId()==id){
                return stuMation;
            }

        }
        return null;
    }


}

