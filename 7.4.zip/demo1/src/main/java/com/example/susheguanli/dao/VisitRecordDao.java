package com.example.susheguanli.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.susheguanli.doman.VisitRecord;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Mapper

@Repository
public interface VisitRecordDao extends BaseMapper<VisitRecord> {
    VisitRecord getVisitRecord(@Param("touristName") String touristName,
                           @Param("touristNum") String touristNum
            , @Param("visitingDormitory") String visitingDormitory
            , @Param("visitingCourse") String visitingCourse
            , @Param("visitingTel") String visitingTel);
}