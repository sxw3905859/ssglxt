package com.example.susheguanli.doman;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

@TableName("sg_visiting_records")
public class VisitRecord {
    @TableId("tourist_id")
    private  Integer touristId;
    private  String touristName;
    private  String touristNum;
    private  String visitingDormitory;
    private String visitingCourse;
    private String visitingTel;

    @Override
    public String toString() {
        return "VisitRecord{" +
                "touristId=" + touristId +
                ", touristName='" + touristName + '\'' +
                ", touristNum='" + touristNum + '\'' +
                ", visitingDormitory='" + visitingDormitory + '\'' +
                ", visitingCourse='" + visitingCourse + '\'' +
                ", visitingTel='" +visitingTel + '\'' +
                '}';
    }

    public Integer getTouristId() {
        return touristId;
    }
    public void setTouristId(Integer touristId) {
        this.touristId = touristId;
    }

    public String getTouristName() {
        return touristName;
    }
    public void setTouristName(String touristName) {
        this.touristName = touristName;
    }

    public String getTouristNum() {
        return touristNum;
    }
    public void setTouristNum(String touristNum) {
        this.touristNum = touristNum;
    }

    public String getVisitingDormitory() {
        return visitingDormitory;
    }
    public void setVisitingDormitory(String visitingDormitory) {
        this.visitingDormitory = visitingDormitory;
    }

    public String getVisitingCourse() {
        return visitingCourse;
    }
    public void setVisitingCourse(String visitingCourse) {
        this.visitingCourse = visitingCourse;
    }

    public String getVisitingTel() {
        return visitingTel;
    }
    public void setVisitingTel(String visitingTel) {
        this.visitingTel = visitingTel;
    }

}