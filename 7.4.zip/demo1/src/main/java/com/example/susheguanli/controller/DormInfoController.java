package com.example.susheguanli.controller;

import com.example.susheguanli.doman.DormInfo;
import com.example.susheguanli.service.DormInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/dormInfo")
@CrossOrigin
public class DormInfoController {
    @Autowired
    private DormInfoService dormInfoservice;
    @GetMapping
    public List<DormInfo> getAll(){
        System.out.println(65);
        List<DormInfo>  list= dormInfoservice.list();

        for (DormInfo dormInfo :list){
            System.out.println(dormInfo.toString());
        }
        return dormInfoservice.list();
    }
    @GetMapping("/search/{name}")
    public DormInfo getByName(@PathVariable Integer name){
        System.out.println(name);
        List<DormInfo> dormInfoList= dormInfoservice.list();
        for (DormInfo dormInfo: dormInfoList){
            if(dormInfo.getDormitoryNum().equals(name)){
                System.out.println("+++"+dormInfo.getDormitoryNum());
                return dormInfo;
            }

        }
        return null;
    }

    @GetMapping("/{id}")
    public DormInfo getByid(@PathVariable int id){

        List<DormInfo> dormInfoList= dormInfoservice.list();
        for (DormInfo dormInfo: dormInfoList){
            if(dormInfo.getDormitoryId()==id){
                return dormInfo;
            }

        }
        return null;
    }


}

