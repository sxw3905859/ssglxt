package com.example.susheguanli.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.susheguanli.dao.StuMationDao;
import com.example.susheguanli.doman.StuMation;
import com.example.susheguanli.service.StuMationservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StuMationServiceImpl extends ServiceImpl<StuMationDao,StuMation> implements StuMationservice {

    @Autowired
    StuMationDao stuMationDao;

    @Override
    public StuMation getStuMation(String studentNum, String studentName, String studentNational
            , String studentClass, String studentGender, String studentTel) {
        return stuMationDao.getStuMation(studentNum , studentName,studentNational,studentClass,studentGender,studentTel);
    }
}
