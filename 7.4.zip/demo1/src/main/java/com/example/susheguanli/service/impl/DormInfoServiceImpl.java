package com.example.susheguanli.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.susheguanli.dao.DormInfoDao;
import com.example.susheguanli.doman.DormInfo;
import com.example.susheguanli.service.DormInfoService;
import org.springframework.stereotype.Service;

@Service
public class DormInfoServiceImpl extends ServiceImpl<DormInfoDao, DormInfo> implements DormInfoService {
}
