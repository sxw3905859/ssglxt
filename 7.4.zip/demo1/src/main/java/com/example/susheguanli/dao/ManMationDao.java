package com.example.susheguanli.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.susheguanli.doman.ManMation;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Mapper

@Repository
public interface ManMationDao extends BaseMapper<ManMation> {
    ManMation getManMation(@Param("managerNum") Integer managerNum,
                           @Param("managerName") String managerName
            , @Param("managerCard") String managerCard
            , @Param("managerGender") String managerGender
            , @Param("managerBirthday") String managerBirthday
            , @Param("managerNational") String managerNational
            , @Param("managerNational") String managerBuilding
            , @Param("managerNational") String managerTel
            , @Param("managerNational") String managerQq
            , @Param("managerNational") String managerEmail);
}