package com.example.susheguanli.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.susheguanli.dao.UsersDao;
import com.example.susheguanli.doman.Users;
import com.example.susheguanli.service.Userservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UsersServiceImpl extends ServiceImpl<UsersDao, Users> implements Userservice {

    @Autowired
    UsersDao userDao;

    @Override
    public Users getUser(String userName , String userPassword) {
        return userDao.getUser(userName , userPassword);
    }
}
