package com.example.susheguanli.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.susheguanli.doman.StuMation;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Mapper

@Repository
public interface StuMationDao extends BaseMapper<StuMation> {
    StuMation getStuMation(@Param("studentNum") String studentNum, @Param("studentName") String studentName
            , @Param("studentNational") String studentNational
            , @Param("studentClass") String studentClass
            , @Param("studentGender") String studentGender
            , @Param("studentTel") String studentTel);
}
