package com.example.susheguanli.doman;
/*宿管查阅学生信息*/

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

@TableName("xs_student_information")
public class StuMation {
    @TableId("student_id")
    private  Integer studentId;
    private  String studentNum;
    private  String studentName;
    private  String studentNational;
    private String studentClass;
    private String studentGender;
    private String studentTel;

    @Override
    public String toString() {
        return "StuMation{" +
                "studentId=" + studentId +
                ", studentNum='" + studentNum + '\'' +
                ", studentName='" + studentName + '\'' +
                ", studentNational='" + studentNational + '\'' +
                ", studentClass='" + studentClass + '\'' +
                ", studentGender='" + studentGender + '\'' +
                ", studentTel='" + studentTel + '\'' +
                '}';
    }

    public Integer getStudentId() {
        return studentId;
    }
    public void setstudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public String getStudentNum() {
        return studentNum;
    }

    public void setStudentNum(String studentNum) {
        this.studentNum = studentNum;
    }
    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }
    public String getStudentNational() {
        return studentNational;
    }

    public void setStudentNational(String studentNational) {
        this.studentNational = studentNational;
    }
    public String getStudentGender() {
        return studentGender;
    }

    public void setStudentGender(String studentGender) {
        this.studentGender = studentGender;
    }
    public String getStudentTel() {
        return studentTel;
    }

    public void setStudentTel(String studentTel) {
        this.studentTel = studentTel;
    }
    public String getStudentClass() {
        return studentClass;
    }
    public void setStudentClass(String studentClass) {
        this.studentClass = studentClass;
    }
}