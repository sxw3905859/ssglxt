package com.example.susheguanli.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.susheguanli.doman.StuMation;


public interface StuMationservice extends IService<StuMation>{
    StuMation getStuMation(String studentNum, String studentName, String studentNational
            , String studentClass, String studentGender, String studentTel);
}

