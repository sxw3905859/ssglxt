package com.example.susheguanli.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.susheguanli.doman.Users;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface UsersDao extends BaseMapper<Users> {
    Users getUser(@Param("userName") String userName, @Param("userPassword") String passWord);
}

