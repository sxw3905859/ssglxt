package com.example.susheguanli.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.susheguanli.doman.Users;

public interface Userservice extends IService<Users> {

    Users getUser(String userName, String userPassword);
}
