package com.example.susheguanli.controller;

import com.example.susheguanli.doman.Users;
import com.example.susheguanli.service.Userservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
@CrossOrigin
public class UsersController {
    @Autowired
    private Userservice usersService;
    @GetMapping
    public List<Users> getAll(){
        return usersService.list();
    }

    @PostMapping
    public String login(@RequestBody Users users , @RequestParam(value = "login" , defaultValue = "true") boolean login) throws Exception{
        System.out.println(users.getUserName()+users.getUserPassword());
        Users a = usersService.getUser(users.getUserName() , users.getUserPassword());
        if (a!=null){
            System.out.println("chenggong");
            return "1111";
        }
        else {
            return "2222";
            //throw new Exception("登陆失败！");
        }

    }
    @PutMapping
    public int login1(Users users){
        System.out.println(users.getUserName()+"..."+users.getUserPassword());
        return 1;
    }
    public boolean update(@RequestBody Users users){
        return usersService.updateById(users);
    }
    @GetMapping("/{id}")
    public Users getByid(@PathVariable int id){
        return usersService.getById(id);
    }


}
