package com.example.susheguanli.controller;

import com.example.susheguanli.doman.Users;
import com.example.susheguanli.service.Userservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
@CrossOrigin
public class UsersController {
    @Autowired
    private Userservice usersService;
    @GetMapping
    public List<Users> getAll(){
        return usersService.list();
    }

    @GetMapping ("/login")
    public Boolean logins (@RequestParam String userName,@RequestParam String userPassword){
        List<Users> usersList=usersService.list();
        System.out.println(userName+"++++++"+userPassword);

        for( Users users:usersList){
            System.out.println(users.getUserName()+"----"+users.getUserPassword());
            if(users.getUserName().equals(userName)&& users.getUserPassword().equals(userPassword)){
                return true;
            }
        }
        return false;
    }
    @PutMapping
    public int login1(Users users){
        System.out.println(users.getUserName()+"..."+users.getUserPassword());
        return 1;
    }
    public boolean update(@RequestBody Users users){
        return usersService.updateById(users);
    }
    @GetMapping("/{id}")
    public Users getByid(@PathVariable int id){
        return usersService.getById(id);
    }


}
